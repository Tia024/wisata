# jogja.travel
Web Animated HTML Css - Template untuk web travel

## Berikut tampilan yang di buat.

![alt text](https://github.com/januriawan/jogja.travel/blob/master/aset/front.jpg)
